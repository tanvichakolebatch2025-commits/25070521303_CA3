import { useEffect, useMemo, useState } from "react";
import { Wallet, TrendingUp, TrendingDown, PiggyBank, Plus, Trash2, Pencil, RefreshCw, LayoutDashboard, ChartPie, Target, ArrowUpRight } from "lucide-react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts";
import {
  getTransactions, addTransaction, updateTransaction, deleteTransaction,
  getBudgets, saveBudget, deleteBudget
} from "./services/api";

const money = (value) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(value || 0);
const today = new Date().toISOString().slice(0, 10);
const emptyForm = { title: "", amount: "", type: "expense", category: "Food", date: today, notes: "" };
const colors = ["#6c63ff", "#28b89a", "#ffad5c", "#ef6b83", "#4b9de8", "#a17bd8", "#7d91a8"];

export default function App() {
  const [transactions, setTransactions] = useState([]);
  const [budgets, setBudgets] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [view, setView] = useState("Dashboard");
  const [budgetForm, setBudgetForm] = useState({ category: "Food", amount: "", month: String(new Date().getMonth() + 1), year: String(new Date().getFullYear()) });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function loadData() {
    setBusy(true); setError("");
    try {
      const [tx, bg] = await Promise.all([getTransactions(), getBudgets()]);
      setTransactions(tx); setBudgets(bg);
    } catch {
      setError("Cannot connect to the server. Check that MongoDB and the backend are running.");
    } finally { setBusy(false); }
  }

  useEffect(() => { loadData(); }, []);

  const totals = useMemo(() => {
    const income = transactions.filter((t) => t.type === "income").reduce((sum, t) => sum + Number(t.amount), 0);
    const expenses = transactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + Number(t.amount), 0);
    return { income, expenses, balance: income - expenses };
  }, [transactions]);

  const chartData = useMemo(() => {
    const grouped = {};
    transactions.filter((t) => t.type === "expense").forEach((t) => { grouped[t.category] = (grouped[t.category] || 0) + Number(t.amount); });
    return Object.entries(grouped).map(([name, value]) => ({ name, value }));
  }, [transactions]);

  async function submitTransaction(event) {
    event.preventDefault(); setError(""); setNotice("");
    try {
      const payload = { ...form, amount: Number(form.amount), date: form.date || today };
      if (editingId) await updateTransaction(editingId, payload);
      else await addTransaction(payload);
      setForm(emptyForm); setEditingId(null); setNotice(editingId ? "Transaction updated." : "Transaction added.");
      await loadData();
    } catch (e) { setError(e.response?.data?.message || "Could not save transaction."); }
  }

  function startEdit(t) {
    setEditingId(t._id);
    setForm({ title: t.title, amount: t.amount, type: t.type, category: t.category, date: new Date(t.date).toISOString().slice(0, 10), notes: t.notes || "" });
    setView("Transactions");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function removeTransaction(id) {
    if (!window.confirm("Delete this transaction?")) return;
    try { await deleteTransaction(id); setNotice("Transaction deleted."); await loadData(); }
    catch { setError("Could not delete transaction."); }
  }

  async function submitBudget(event) {
    event.preventDefault(); setError(""); setNotice("");
    try {
      await saveBudget({ ...budgetForm, amount: Number(budgetForm.amount), month: Number(budgetForm.month), year: Number(budgetForm.year) });
      setBudgetForm((f) => ({ ...f, amount: "" })); setNotice("Budget saved."); await loadData();
    } catch (e) { setError(e.response?.data?.message || "Could not save budget."); }
  }

  async function removeBudget(id) {
    if (!window.confirm("Delete this budget?")) return;
    try { await deleteBudget(id); setNotice("Budget deleted."); await loadData(); }
    catch { setError("Could not delete budget."); }
  }

  const navItems = [
    { label: "Dashboard", icon: LayoutDashboard },
    { label: "Transactions", icon: Wallet },
    { label: "Budgets", icon: Target },
    { label: "Analytics", icon: ChartPie }
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark"><Wallet size={22} /></span><span>finora<small>PERSONAL FINANCE</small></span></div>
        <div className="nav-label">WORKSPACE</div>
        <nav>{navItems.map(({ label, icon: Icon }) => <button key={label} className={`nav-item ${view === label ? "active" : ""}`} onClick={() => setView(label)}><Icon size={18} />{label}{label === "Dashboard" && <span className="nav-dot" />}</button>)}</nav>
        <div className="sidebar-bottom"><div className="tip-icon">✦</div><strong>Small steps add up.</strong><p>Build better money habits, one day at a time.</p><div className="sidebar-footer">FINORA · MONEY, MADE CLEAR</div></div>
      </aside>

      <main className="main-content">
        <header className="topbar"><div><div className="eyebrow">YOUR MONEY, IN FOCUS</div><h1>{view === "Dashboard" ? "Dashboard" : view}</h1></div><button className="refresh-btn" onClick={loadData} title="Refresh data"><RefreshCw size={16} /> Refresh</button></header>
        {error && <div className="alert error">{error}</div>}
        {notice && <div className="alert success">{notice}</div>}

        {view === "Dashboard" && <>
          <section className="welcome-card"><div><span className="welcome-tag">YOUR FINANCIAL SNAPSHOT</span><h2>Make every rupee count.</h2><p>Understand your spending, plan your budget, and stay in control.</p></div><div className="welcome-art"><div className="art-circle"><Wallet size={38} /></div><span className="art-spark spark-one">✦</span><span className="art-spark spark-two">✧</span></div></section>
          <section className="summary-grid">
            <SummaryCard title="Total Balance" value={money(totals.balance)} caption="Income minus expenses" icon={Wallet} tone="purple" />
            <SummaryCard title="Total Income" value={money(totals.income)} caption="Money coming in" icon={TrendingUp} tone="green" />
            <SummaryCard title="Total Expenses" value={money(totals.expenses)} caption="Money going out" icon={TrendingDown} tone="orange" />
            <SummaryCard title="Savings Rate" value={`${totals.income > 0 ? Math.round((totals.balance / totals.income) * 100) : 0}%`} caption="Of your total income" icon={PiggyBank} tone="blue" />
          </section>
          <section className="content-grid">
            <div className="panel transactions-panel"><div className="panel-heading"><div><h3>Recent transactions</h3><p>Your latest money activity</p></div><button className="text-button" onClick={() => setView("Transactions")}>View all <ArrowUpRight size={15} /></button></div><TransactionTable items={transactions.slice(0, 5)} onEdit={startEdit} onDelete={removeTransaction} /></div>
            <div className="panel chart-panel"><div className="panel-heading"><div><h3>Spending breakdown</h3><p>Expenses by category</p></div></div>{chartData.length ? <div className="chart-wrap"><ResponsiveContainer width="100%" height={220}><PieChart><Pie data={chartData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={82} paddingAngle={3}>{chartData.map((entry, i) => <Cell key={entry.name} fill={colors[i % colors.length]} />)}</Pie><Tooltip formatter={(v) => money(v)} /><Legend verticalAlign="bottom" height={34} /></PieChart></ResponsiveContainer></div> : <EmptyState text="Your spending chart will appear after you add an expense." />}</div>
          </section>
        </>}

        {view === "Transactions" && <section className="content-grid transaction-page">
          <div className="panel form-panel"><div className="panel-heading"><div><h3>{editingId ? "Edit transaction" : "Add a transaction"}</h3><p>Record income or an expense</p></div></div>
            <form onSubmit={submitTransaction} className="form-stack">
              <label>Transaction name<input required maxLength="100" placeholder="e.g. Grocery shopping" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></label>
              <div className="form-row"><label>Amount (₹)<input required type="number" min="0.01" step="0.01" placeholder="0.00" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></label><label>Type<select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}><option value="expense">Expense</option><option value="income">Income</option></select></label></div>
              <div className="form-row"><label>Category<select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{["Food","Transport","Shopping","Bills","Education","Health","Salary","Freelance","Entertainment","Other"].map((c) => <option key={c}>{c}</option>)}</select></label><label>Date<input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></label></div>
              <label>Notes (optional)<textarea rows="3" placeholder="Add a note..." value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></label>
              <button className="primary-btn" type="submit"><Plus size={17} /> {editingId ? "Update transaction" : "Save transaction"}</button>
              {editingId && <button className="secondary-btn" type="button" onClick={() => { setEditingId(null); setForm(emptyForm); }}>Cancel edit</button>}
            </form>
          </div>
          <div className="panel transactions-panel"><div className="panel-heading"><div><h3>All transactions</h3><p>{transactions.length} records saved</p></div></div><TransactionTable items={transactions} onEdit={startEdit} onDelete={removeTransaction} /></div>
        </section>}

        {view === "Budgets" && <section className="content-grid transaction-page">
          <div className="panel form-panel"><div className="panel-heading"><div><h3>Plan a budget</h3><p>Set a spending limit by category</p></div></div>
            <form className="form-stack" onSubmit={submitBudget}>
              <label>Category<select value={budgetForm.category} onChange={(e) => setBudgetForm({ ...budgetForm, category: e.target.value })}>{["Food","Transport","Shopping","Bills","Education","Health","Entertainment","Other"].map((c) => <option key={c}>{c}</option>)}</select></label>
              <label>Monthly limit (₹)<input type="number" min="0.01" step="0.01" required placeholder="e.g. 5000" value={budgetForm.amount} onChange={(e) => setBudgetForm({ ...budgetForm, amount: e.target.value })} /></label>
              <div className="form-row"><label>Month<select value={budgetForm.month} onChange={(e) => setBudgetForm({ ...budgetForm, month: e.target.value })}>{Array.from({length:12}, (_, i) => <option key={i+1} value={i+1}>{new Date(2000, i).toLocaleString("en-IN", {month:"long"})}</option>)}</select></label><label>Year<input type="number" min="2020" max="2100" value={budgetForm.year} onChange={(e) => setBudgetForm({ ...budgetForm, year: e.target.value })} /></label></div>
              <button className="primary-btn" type="submit"><Target size={17} /> Save budget</button>
            </form>
          </div>
          <div className="panel"><div className="panel-heading"><div><h3>Your budgets</h3><p>Monthly limits saved in MongoDB</p></div></div>
            {budgets.length ? <div className="budget-list">{budgets.map((b) => {
              const spent = transactions.filter((t) => t.type === "expense" && t.category === b.category && new Date(t.date).getMonth()+1 === b.month && new Date(t.date).getFullYear() === b.year).reduce((s,t) => s+Number(t.amount),0);
              const percent = Math.min(100, Math.round(spent / b.amount * 100));
              return <div className="budget-item" key={b._id}><div className="budget-line"><div><strong>{b.category}</strong><small>{new Date(2000,b.month-1).toLocaleString("en-IN",{month:"long"})} {b.year}</small></div><button className="icon-btn danger" onClick={() => removeBudget(b._id)} aria-label="Delete budget"><Trash2 size={16}/></button></div><div className="budget-numbers"><span>{money(spent)} spent</span><span>Limit {money(b.amount)}</span></div><div className="progress-track"><div className={`progress-fill ${percent >= 100 ? "over" : ""}`} style={{width: `${percent}%`}} /></div><small className={percent >= 100 ? "over-text" : "muted"}>{percent}% used{spent > b.amount ? " · Over budget" : ""}</small></div>;
            })}</div> : <EmptyState text="No budgets yet. Add a monthly limit using the form."/>}
          </div>
        </section>}

        {view === "Analytics" && <section className="content-grid analytics-grid">
          <div className="panel chart-panel"><div className="panel-heading"><div><h3>Expense categories</h3><p>How your spending is distributed</p></div></div>{chartData.length ? <ResponsiveContainer width="100%" height={310}><PieChart><Pie data={chartData} dataKey="value" nameKey="name" innerRadius={75} outerRadius={112} paddingAngle={3}>{chartData.map((entry, i) => <Cell key={entry.name} fill={colors[i % colors.length]} />)}</Pie><Tooltip formatter={(v) => money(v)} /><Legend /></PieChart></ResponsiveContainer> : <EmptyState text="Add expenses to view analytics."/>}</div>
          <div className="panel insight-panel"><div className="panel-heading"><div><h3>Money overview</h3><p>A quick look at your totals</p></div></div><div className="insight-row"><span>Income</span><strong className="income-text">{money(totals.income)}</strong></div><div className="insight-row"><span>Expenses</span><strong className="expense-text">{money(totals.expenses)}</strong></div><div className="insight-row"><span>Net balance</span><strong>{money(totals.balance)}</strong></div><div className="insight-note">Tip: Review your categories regularly to understand where your money goes.</div></div>
        </section>}
        <footer className="page-footer">Finora · Smart Expense Tracker & Budget Planner <span>{busy ? "Syncing…" : "Connected to your workspace"}</span></footer>
      </main>
    </div>
  );
}

function SummaryCard({ title, value, caption, icon: Icon, tone }) {
  return <article className="summary-card"><div className="summary-top"><span>{title}</span><span className={`summary-icon ${tone}`}><Icon size={19}/></span></div><strong>{value}</strong><small>{caption}</small></article>;
}

function EmptyState({ text }) {
  return <div className="empty-state"><div className="empty-icon"><Wallet size={23}/></div><p>{text}</p></div>;
}

function TransactionTable({ items, onEdit, onDelete }) {
  if (!items.length) return <EmptyState text="No transactions yet. Add your first transaction to get started."/>;
  return <div className="table-wrap"><table><thead><tr><th>TRANSACTION</th><th>CATEGORY</th><th>DATE</th><th>AMOUNT</th><th></th></tr></thead><tbody>{items.map((t) => <tr key={t._id}><td><div className="transaction-title"><span className={`transaction-symbol ${t.type}`}>{t.type === "income" ? "↙" : "↗"}</span><div><strong>{t.title}</strong>{t.notes && <small>{t.notes}</small>}</div></div></td><td><span className="category-pill">{t.category}</span></td><td>{new Date(t.date).toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"2-digit" })}</td><td className={`amount-cell ${t.type}`}>{t.type === "income" ? "+" : "−"}{money(t.amount)}</td><td><div className="row-actions"><button className="icon-btn" onClick={() => onEdit(t)} aria-label="Edit transaction"><Pencil size={15}/></button><button className="icon-btn danger" onClick={() => onDelete(t._id)} aria-label="Delete transaction"><Trash2 size={15}/></button></div></td></tr>)}</tbody></table></div>;
}
