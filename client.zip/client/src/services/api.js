import axios from "axios";

const api = axios.create({ baseURL: "http://localhost:5000/api" });

export const getTransactions = () => api.get("/transactions").then((r) => r.data);
export const addTransaction = (data) => api.post("/transactions", data).then((r) => r.data);
export const updateTransaction = (id, data) => api.put(`/transactions/${id}`, data).then((r) => r.data);
export const deleteTransaction = (id) => api.delete(`/transactions/${id}`).then((r) => r.data);
export const getBudgets = () => api.get("/budgets").then((r) => r.data);
export const saveBudget = (data) => api.post("/budgets", data).then((r) => r.data);
export const deleteBudget = (id) => api.delete(`/budgets/${id}`).then((r) => r.data);
