const express = require("express");
const mongoose = require("mongoose");
const Budget = require("../models/Budget");

const router = express.Router();

router.get("/", async (_req, res) => {
  try {
    res.json(await Budget.find().sort({ year: -1, month: -1, category: 1 }));
  } catch {
    res.status(500).json({ message: "Could not load budgets" });
  }
});

router.post("/", async (req, res) => {
  try {
    const { category, amount, month, year } = req.body;
    if (!category || Number(amount) <= 0 || !month || !year) {
      return res.status(400).json({ message: "Enter category, positive amount, month, and year." });
    }
    const budget = await Budget.findOneAndUpdate(
      { category, month: Number(month), year: Number(year) },
      { category, amount: Number(amount), month: Number(month), year: Number(year) },
      { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
    );
    res.status(201).json(budget);
  } catch (error) {
    res.status(400).json({ message: error.message || "Could not save budget" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid budget ID" });
    const budget = await Budget.findByIdAndDelete(req.params.id);
    if (!budget) return res.status(404).json({ message: "Budget not found" });
    res.json({ message: "Budget deleted" });
  } catch {
    res.status(500).json({ message: "Could not delete budget" });
  }
});

module.exports = router;
