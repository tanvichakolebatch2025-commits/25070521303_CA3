const express = require("express");
const mongoose = require("mongoose");
const Transaction = require("../models/Transaction");

const router = express.Router();

router.get("/", async (_req, res) => {
  try {
    const transactions = await Transaction.find().sort({ date: -1, createdAt: -1 });
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ message: "Could not load transactions" });
  }
});

router.post("/", async (req, res) => {
  try {
    const { title, amount, type, category, date, notes } = req.body;
    if (!title || !category || !["income", "expense"].includes(type) || Number(amount) <= 0) {
      return res.status(400).json({ message: "Enter a title, valid amount, type, and category." });
    }
    const transaction = await Transaction.create({ title, amount: Number(amount), type, category, date: date || Date.now(), notes });
    res.status(201).json(transaction);
  } catch (error) {
    res.status(400).json({ message: error.message || "Could not create transaction" });
  }
});

router.put("/:id", async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid transaction ID" });
    const transaction = await Transaction.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!transaction) return res.status(404).json({ message: "Transaction not found" });
    res.json(transaction);
  } catch (error) {
    res.status(400).json({ message: error.message || "Could not update transaction" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Invalid transaction ID" });
    const transaction = await Transaction.findByIdAndDelete(req.params.id);
    if (!transaction) return res.status(404).json({ message: "Transaction not found" });
    res.json({ message: "Transaction deleted" });
  } catch (error) {
    res.status(500).json({ message: "Could not delete transaction" });
  }
});

module.exports = router;
